
    <select class="form-control select_dt" id="appo_time" name="appo_time">
        <?php foreach($tmes as $tme) {?>

        <option value="<?php echo $tme; ?>">
            <?php echo $tme; ?>
        </option>


        <?php } ?>
    </select>

